#include<stdio.h>
#include<math.h>
int main(){
	int bin,aux;
	int i=0,num = 0;
	printf("Entre com o numero em notacao binaria : ");
	scanf("%d",&bin);

	aux = bin;
	while(aux>0){
		num+=(aux%10)*pow(2,i);
		aux = aux/10;
		i++;
	}	
	printf("\nO numero %d em binario equivale a %d em decimal\n",bin,num);
	return 0;
}
