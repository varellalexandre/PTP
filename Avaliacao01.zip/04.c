#include<stdio.h>
int main(){
	int l,c,sl=0,sc=0,sd=0,i,j,num=0;
	printf("Entre com as dimensoes da matriz (linha coluna): ");
	scanf("%d %d",&l,&c);
	if(l!=c){
		printf("\nUma matriz so pode ser um quadrado magico se for uma matriz quadrada!\n");
		return 0;
	}
	else{
		int matriz[l][c];
		printf("\nEntre com os valores dos elementos da matriz:\n");
		
		for(i=0 ; i<l ; i++)
			for(j=0 ; j<c ;j++)
				scanf("%d",&matriz[i][j]);

		for(i=0 ; i<l ; i++){
			num = 0;
			for(j=0 ; j<c ; j++){
				num+=matriz[i][j];
				num+=matriz[j][i];
				
				if(i == j)
					sd+=matriz[i][j];
				if(i+j == l-1)
					sd+=matriz[i][j];
			}
		
			if(i == 0){
				sl = num;
				sc = num;
			}
			if(sl != num || sc != num){
				printf("Esta matriz nao e um quadrado magico!\n");
				return 0;
			}

		}

		if(!(sl == sc && sd == sc)){
			printf("Esta matriz nao e um quadrado magico!\n");
			return 0;
		}

	}

	printf("Essa matriz e um quadrado magico!\n");
	return 0;
	
}